﻿/*tinymce.init({   
    language: "en",
    theme: 'modern',
     menubar:false,
    plugins: [
      'advlist autolink lists link  charmap print preview hr anchor pagebreak',
      'searchreplace wordcount visualblocks visualchars fullscreen',
      'insertdatetime nonbreaking save table contextmenu directionality',
      'paste textcolor colorpicker textpattern  codesample toc'
    ],
    toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent',
    toolbar2: 'print preview | forecolor backcolor | codesample help',
    image_advtab: true,
    theme_advanced_resizing: true,
    theme_advanced_resizing_use_cookie : false,
      height: '100',
    width : 50
});

plugins: [
      'advlist autolink lists link image charmap print preview hr anchor pagebreak',
      'searchreplace wordcount visualblocks visualchars code fullscreen',
      'insertdatetime media nonbreaking save table contextmenu directionality',
      'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc help'
],
   toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
*/