<footer class="container-fluid" style="margin-top: 0px;">
        <div class="row">
         <div class="col-sm-4">
                <h3>Useful links</h3>
                <ul class="nav-menu">
                    <li><a href="index.php#top">Home</a></li>
                    <li><a href="index.php#About">About Us</a></li>
                    <li><a href="index.php#Courses">Online Courses</a></li>
                    <li><a href="allcourses.php">All Courses</a></li>
                    <li><a href="allLibrary.php">Library</a></li>
                    <li><a href="allEvents.php">Events</a></li>
                    <li><a href="index.php#Faq">FAQ</a></li>
                    <li><a href="index.php#Contact">Contact Us</a></li>
                </ul>
            </div>
            <div class="col-sm-4">         
                <ul class="footer-ul inline-dis rotate">
                    <li class="facebook">
                        <a href="https://www.facebook.com/ECPPuptodatepharmacist/"><i class="fa fa-facebook-official fa-2x"></i></a>
                    </li>
                    <li class="google">
                        <a href="#"><i class="fa fa-google-plus fa-2x"></i></a>
                    </li>
                    <li class="twitter">
                        <a href="https://twitter.com/ECPP3"><i class="fa fa-twitter fa-2x"></i></a>
                    </li>
                    <li class="insta">
                        <a href="#"><i class="fa fa-instagram fa-2x" aria-hidden="true"></i></a>
                    </li>
                </ul>
            </div>
            <div class="col-sm-4">                  
                <div class="social-btns">
                    <p> <i class="fa fa-envelope-open-o" aria-hidden="true"></i> info@ecpp-ph.com</p>
                    <p><a class="twitter-follow-button" href="https://twitter.com/ECPP3">Follow @ECPP3</a></p>
                    <div class="fb-like" data-href="https://www.facebook.com/ECPPuptodatepharmacist/" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="false"></div>
                </div>               
            </div>
        </div>
         <div class="copyright">Copyright &copy; 2017 ECPP. All rights reserved. Designed by <a href="http://quick-picker.com" target="_blank">Quick Picker</a></div>
    </footer>
     <script src="js/jquery-1.12.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/web.js"></script>
    </body>
</html>